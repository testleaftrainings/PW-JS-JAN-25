import { TestInfo } from "@playwright/test";
import { createIssue } from "./jiraintegration";



export async  function logDefectissue(testinfo:TestInfo){

  if(testinfo.status==='timedOut'|| testinfo.status==='failed'){
    const summary=`The  ${testinfo.title} is failed`
    const desc=`Due to ${testinfo.error}`
    const   key= createIssue(summary,desc)
    return key;

  }

}