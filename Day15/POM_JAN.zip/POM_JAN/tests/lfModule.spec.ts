import {test} from "../customFixtures/myFixtures"
import { CreateLeadPage } from '../pages/leads/createLeadpage'
import { CreateAccountPage } from '../pages/accounts/createAccountpage'
import fs from 'fs'
import path from 'path'
import { URL } from "../DataFiles/urlConstants"
import { createIssue } from "../jira/jiraintegration"
import { logDefectissue } from "../jira/logDefect"
import { text } from "stream/consumers"

let loginData:any
test.beforeEach(`readJsondata`,async()=>{

    loginData=JSON.parse(fs.readFileSync('DataFiles/loginCredentials.json','utf-8'))
})

test(`Leads Module`,async({cl,ca})=>{
  
    await cl.launchApp(URL.baseUrl)
    await cl.enterCredentials(loginData[0].username,loginData[0].password)
    await cl.clickLogin()
    await cl.clickCRM()
    await cl.clickLeads()
    await cl.clickCreateLead()
    await cl.enterMandatoryforCLfields()
    await cl.clickSubmit()
    await ca.clickAccounts()
   // createIssue()
})
