Agenda:
------
POM Recap
POM with customFixture
POM with Utility(Wrapper methods)
POM with Jira
classroom
Framework Best practices
Framework Walkthrough
-------------------------------------------
Day :2
Custom retry
Custom Reports
Network interception
GithubActions -ci integration
Hands on

abstraction 
  -->show the necessary details and hide the details not necessary for the user 

  interface -->completely hidden with implemation only the usage 
            -->design -->doesnot have implementation(body)
  abstract class
       --->it has both implemented and not implemented method 

In Inheritance -->we cannot acheieve multiple inheritance
  -->can be acheived through interface 

  a class  extends other class
  a class can implement interface
  interface can extends other interface
  abstraclass extends other abstract class
  a class can extends abstract class

  similar class can be interhited 

  class  extends abstract class implements interface1, interface2

POM -->design pattern separate implementation for pageaction/pageobjects and testcase
      -->reusability
      -->scalability
      -->modularity
      -->easy maintenance

Adapter design pattern -->implementing both UI and API Integration
Factory pattern -->
Decorator pattern-->reporter
Bridge pattern


basePage --->Welcomepage--->Homepage-->Leadspage -->cLpage
                                    -->accountspage-->capage

axios ->node library -->connect any third party appications
common library 

pw-api 

npm install axios

jira -->basic authorization
apikey 
ATATT3xFfGF0o9Il-GXAzXbgMaUqc43VhYkO2qVQP6y7-7pD7DOpJAiR1Ru83l9m1Gldi4rrHTyVZDUG0ohBPx543hcCrL5pDh66kqZ6qnH7uhcqCoP4X-GOQU29q3PzYnrLPUAqb6F4PrvGYlMa-me3nMmdUnkgt-rKpssMqMWIlU7tSWR9KiM=EB88E30F